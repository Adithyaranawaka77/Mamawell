* Use TurnitIn software (https://library.sliit.lk/pages/turnitin)

* Generate "Similarity Report" for all reports.

* Rename group report to your project ID

* Rename individual reports to your registration number.