Include research paper in .pdf format.

Publication details should be submitted to online form in the courseweb before deadline.
Publication mark evaluation will be considered from online form only.