* Use TurnitIn software (https://library.sliit.lk/pages/turnitin)

* Generate "Similarity Report"

* Rename to your project ID